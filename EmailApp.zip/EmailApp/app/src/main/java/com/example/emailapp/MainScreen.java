package com.example.emailapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private void email() {

        TextInputEditText login = (Button) findViewById(R.id.login);
        TextInputEditText password = (Button) findViewById(R.id.password);

        TextView usuario = (TextView) findViewById(R.id.usuarioField);
        TextView senha = (TextView) findViewById(R.id.senhaField);


    }

        private void incrementaValor(){
        Button button = (Button) findViewById(R.id.incremento);
        Button tela = (Button) findViewById(R.id.tela);
        TextView texto = (TextView) findViewById(R.id.texto);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String temp = texto.getText().toString();
                int newVal = Integer.parseInt(temp);
                texto.setText(String.valueOf(++newVal));
            }
        });


    Intent i = new Intent(Intent.ACTION_DIAL);
    i.setData(Uri.parse("tel: 8199999999"));

    tela.setOnClickListener(new View.OnClickListener()
        @Override
        public void onClick(View v){
        String s = usuario.getText().toString + "  " + senha.get
        Toast.makeText();
    }



    )
}
