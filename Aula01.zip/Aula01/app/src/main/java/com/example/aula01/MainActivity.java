 package com.example.aula01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

 public class MainActivity extends AppCompatActivity {

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

         buttons();
     }

     private void buttons() {

         Button somar = (Button) findViewById(R.id.somar);
         Button toast = (Button) findViewById(R.id.toast);

         TextView Text1 = (TextView) findViewById(R.id.texto1);

         toast.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Toast.makeText(MainActivity.this, "Toast Button", Toast.LENGTH_SHORT).show();
             }

         });

         somar.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String s = Text1.getText().toString();
                 int result = Integer.parseInt(s);
                 result++;
                 Text1.setText(String.valueOf(result));

             }

         });
     }
 }